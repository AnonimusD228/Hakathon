import pygame as nigger
screen_width = 1200
screen_height = 800
screen_size=screen_width,screen_height
fps=60
bg_color=(0,0,0)
choice_color=(18, 230, 36)
choice_color2=(34, 171, 46)
color1=(5, 34, 255)
color2=(5, 163, 255)
fontcolor=(5, 163, 255)
